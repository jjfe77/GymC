<?php
header("Content-Type: application/json");
require_once "conexion.php";

// Capturar parámetros enviados por POST
$nombre      = isset($_POST['nombre']) ? trim($_POST['nombre']) : "";
$descripcion = isset($_POST['descripcion']) ? trim($_POST['descripcion']) : "";
$estado      = isset($_POST['estado']) ? trim($_POST['estado']) : "";

// Validar datos
if ($nombre === "" || $descripcion === "" || $estado === "") {
    echo json_encode(["error" => "Faltan datos para agregar el equipo"]);
    exit;
}

// Preparar consulta segura
$stmt = $mysqli->prepare("INSERT INTO equipos (nombre, descripcion, estado) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nombre, $descripcion, $estado);

if ($stmt->execute()) {
    echo json_encode([
        "success" => "Equipo agregado correctamente",
        "id_equipo" => $stmt->insert_id
    ]);
} else {
    echo json_encode([
        "error" => "Error al insertar: " . $mysqli->error
    ]);
}

$stmt->close();
$mysqli->close();
?>