<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "conexion.php";

$mysqli->begin_transaction();

try {
    // Datos enviados desde Android
    $idAlumno = intval($_POST['id_alumno']);
    $idRutina = intval($_POST['id_rutina']);
    $idRutinaEjercicio = intval($_POST['id_rutina_ejercicio']);
    $seriesReal = intval($_POST['series_real']);
    $repesReal = intval($_POST['repeticiones_real']);
    $cargaReal = intval($_POST['carga_real']);
    $fecha = $_POST['fecha'];

    // ---------------------------------------------------------
    // 1️⃣ Obtener datos planificados (snapshot)
    // ---------------------------------------------------------
    $sqlPlan = "SELECT re.series, re.repeticiones, re.carga, e.nombre
                FROM rutina_ejercicios re
                INNER JOIN ejercicios e ON e.id_ejercicio = re.id_ejercicio
                WHERE re.id_rutina_ejercicio = ?";
    $stmtPlan = $mysqli->prepare($sqlPlan);
    $stmtPlan->bind_param("i", $idRutinaEjercicio);
    $stmtPlan->execute();
    $resultPlan = $stmtPlan->get_result();

    if ($resultPlan->num_rows == 0) {
        throw new Exception("No existe el ejercicio planificado.");
    }

    $plan = $resultPlan->fetch_assoc();

    $seriesPlan = intval($plan['series']);
    $repesPlan = intval($plan['repeticiones']);
    $cargaPlan = intval($plan['carga']);
    $nombreEjercicio = $plan['nombre'];

    // ---------------------------------------------------------
    // 2️⃣ Insertar en ejercicios_realizados
    // ---------------------------------------------------------
    $sql1 = "INSERT INTO ejercicios_realizados 
            (id_alumno, id_rutina, id_rutina_ejercicio, 
            series_real, repeticiones_real, carga_real, fecha)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt1 = $mysqli->prepare($sql1);
    $stmt1->bind_param("iiiiiss", 
        $idAlumno, $idRutina, $idRutinaEjercicio, 
        $seriesReal, $repesReal, $cargaReal, $fecha
    );

    if (!$stmt1->execute()) {
        throw new Exception("Error en ejercicios_realizados: " . $stmt1->error);
    }

    // ---------------------------------------------------------
    // 3️⃣ Insertar en ejercicios_progreso (SNAPSHOT)
    // ---------------------------------------------------------
    $sql2 = "INSERT INTO ejercicios_progreso 
            (id_alumno, id_rutina, id_rutina_ejercicio,
             series_plan, repes_plan, carga_plan, nombre_ejercicio,
             series_real, repeticiones_real, carga_real, fecha)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt2 = $mysqli->prepare($sql2);
    $stmt2->bind_param(
        "iiiisssiiis",
        $idAlumno,
        $idRutina,
        $idRutinaEjercicio,
        $seriesPlan,
        $repesPlan,
        $cargaPlan,
        $nombreEjercicio,
        $seriesReal,
        $repesReal,
        $cargaReal,
        $fecha
    );

    if (!$stmt2->execute()) {
        throw new Exception("Error en ejercicios_progreso: " . $stmt2->error);
    }

    // Confirmar todo
    $mysqli->commit();
    echo json_encode(["status" => "ok"]);

} catch (Exception $e) {
    $mysqli->rollback();
    echo json_encode(["status" => "error", "msg" => $e->getMessage()]);
}

$mysqli->close();
?>
