<?php


header('Content-Type: text/plain');
include 'conexion.php';

$dni = $_GET['dni'] ?? '';
$nombre = $_GET['nombre'] ?? '';
$apellido = $_GET['apellido'] ?? '';
$rol = $_GET['rol'] ?? '';
$edad = $_GET['edad'] ?? '';
$peso = $_GET['peso'] ?? '';
$altura = $_GET['altura'] ?? '';
$grupo_sanguineo = $_GET['grupo_sanguineo'] ?? '';
$direccion = $_GET['direccion'] ?? '';
$telefono = $_GET['telefono'] ?? '';

if ($dni === '' || $nombre === '' || $apellido === '' || $rol === '') {
    echo "Error: faltan datos obligatorios";
    exit;
}

$stmt = $mysqli->prepare(
    "INSERT INTO usuarios (dni, nombre, apellido, rol, edad, peso, altura, grupo_sanguineo, direccion, telefono)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);

$stmt->bind_param("ssssiddsss", $dni, $nombre, $apellido, $rol, $edad, $peso, $altura, $grupo_sanguineo, $direccion, $telefono);

try {
    if ($stmt->execute()) {
        echo "Usuario agregado correctamente";
    } else {
        echo "Error al agregar usuario";
    }
} catch (mysqli_sql_exception $e) {
    // ✅ Manejo elegante del error de clave duplicada
    if ($e->getCode() == 1062) {
        echo "Error: DNI duplicado";
    } else {
        echo "Error inesperado al agregar usuario";
    }
}

$stmt->close();
$mysqli->close();








/*
header('Content-Type: application/json');
include 'conexion.php'; // Conexión centralizada

// Obtenemos los datos de GET (o POST si lo cambias)
$dni = $_GET['dni'] ?? '';
$nombre = $_GET['nombre'] ?? '';
$apellido = $_GET['apellido'] ?? '';
$rol = $_GET['rol'] ?? '';
$edad = $_GET['edad'] ?? '';
$peso = $_GET['peso'] ?? '';
$altura = $_GET['altura'] ?? '';
$grupo_sanguineo = $_GET['grupo_sanguineo'] ?? '';
$direccion = $_GET['direccion'] ?? '';
$telefono = $_GET['telefono'] ?? '';

if ($dni === '' || $nombre === '' || $apellido === '' || $rol === '') {
    echo json_encode(["error" => "Faltan datos obligatorios"]);
    exit;
}

// Preparar consulta para evitar inyecciones SQL
$stmt = $mysqli->prepare(
    "INSERT INTO usuarios (dni, nombre, apellido, rol, edad, peso, altura, grupo_sanguineo, direccion, telefono)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param("ssssiddsss", $dni, $nombre, $apellido, $rol, $edad, $peso, $altura, $grupo_sanguineo, $direccion, $telefono);

if ($stmt->execute()) {
    echo json_encode(["success" => "Usuario agregado correctamente"]);
} else {
    echo json_encode(["error" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
*/
?>
