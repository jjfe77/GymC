<?php
header("Content-Type: application/json");
require_once "conexion.php"; // tu archivo de conexión a MySQL

$sql = "SELECT id_ejercicio, nombre, descripcion, id_grupo, id_equipo 
        FROM Ejercicios 
        ORDER BY nombre";

$result = $mysqli->query($sql);

$ejercicios = [];
while ($row = $result->fetch_assoc()) {
    $ejercicios[] = $row;
}

echo json_encode($ejercicios, JSON_UNESCAPED_UNICODE);

$mysqli->close();
?>