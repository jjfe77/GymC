<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php"; // usa $mysqli

$response = ["success" => false, "message" => "", "data" => []];

try {
    // Obtener idAlumno desde GET o POST
    $idAlumno = $_GET["idAlumno"] ?? $_POST["idAlumno"] ?? null;

    if (!$idAlumno) {
        throw new Exception("Falta el parámetro idAlumno.");
    }

    // Consulta de rutinas del alumno
    $sqlRutinas = "SELECT id_rutina, nombre 
                   FROM rutinas 
                   WHERE id = ? 
                   ORDER BY id_rutina DESC";

    $stmtRut = $mysqli->prepare($sqlRutinas);
    if (!$stmtRut) {
        throw new Exception("Error al preparar consulta de rutinas: " . $mysqli->error);
    }
    $stmtRut->bind_param("i", $idAlumno);
    $stmtRut->execute();
    $resultRut = $stmtRut->get_result();

    $rutinas = [];
    while ($rutina = $resultRut->fetch_assoc()) {
        $idRutina = (int)$rutina["id_rutina"];
        $nombreRutina = $rutina["nombre"];

        // Obtener ejercicios de la rutina
        $sqlEj = "SELECT re.id_ejercicio, e.nombre, re.series, re.repeticiones, re.carga
                  FROM rutina_ejercicios re
                  INNER JOIN ejercicios e ON re.id_ejercicio = e.id_ejercicio
                  WHERE re.id_rutina = ?";
        $stmtEj = $mysqli->prepare($sqlEj);
        if (!$stmtEj) {
            throw new Exception("Error al preparar consulta de ejercicios: " . $mysqli->error);
        }
        $stmtEj->bind_param("i", $idRutina);
        $stmtEj->execute();
        $resultEj = $stmtEj->get_result();

        $ejercicios = [];
        while ($ej = $resultEj->fetch_assoc()) {
            $ejercicios[] = [
                "id_ejercicio" => (int)$ej["id_ejercicio"],
                "nombre"       => $ej["nombre"],
                "series"       => (int)$ej["series"],
                "repeticiones" => (int)$ej["repeticiones"],
                "carga"        => (float)$ej["carga"]
            ];
        }
        $stmtEj->close();

        $rutinas[] = [
            "id_rutina" => $idRutina,
            "nombre"    => $nombreRutina,
            "ejercicios"=> $ejercicios
        ];
    }
    $stmtRut->close();

    $response["success"] = true;
    $response["message"] = "Rutinas obtenidas correctamente.";
    $response["data"] = $rutinas;

} catch (Exception $e) {
    $response["success"] = false;
    $response["message"] = $e->getMessage();
} finally {
    $mysqli->close();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
