<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "conexion.php";

// Validar parámetro
if (!isset($_GET['id_alumno']) || !is_numeric($_GET['id_alumno'])) {
    echo json_encode(["error" => "Parámetro id_alumno inválido"]);
    exit;
}

$idAlumno = intval($_GET['id_alumno']);

// Consulta: une ejercicios_realizados con rutina_ejercicios y ejercicios
$sql = "SELECT 
            er.fecha,
            e.nombre AS ejercicio,
            COALESCE(re.series, 0) AS series_plan,
            COALESCE(er.series_real, 0) AS series_real,
            COALESCE(re.repeticiones, 0) AS repes_plan,
            COALESCE(er.repeticiones_real, 0) AS repes_real,
            COALESCE(re.carga, 0) AS carga_plan,
            COALESCE(er.carga_real, 0) AS carga_real
        FROM ejercicios_realizados er
        INNER JOIN rutina_ejercicios re 
            ON re.id_rutina_ejercicio = er.id_rutina_ejercicio
        INNER JOIN ejercicios e 
            ON e.id_ejercicio = re.id_ejercicio
        WHERE er.id_alumno = ?
        ORDER BY er.fecha ASC";

$stmt = $mysqli->prepare($sql);
if (!$stmt) {
    echo json_encode(["error" => "Error en prepare: " . $mysqli->error]);
    exit;
}

$stmt->bind_param("i", $idAlumno);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}

echo json_encode($items, JSON_UNESCAPED_UNICODE);

$stmt->close();
$mysqli->close();
?>
