<?php
header("Content-Type: application/json; charset=UTF-8");
require_once "conexion.php";
$idRutina = isset($_GET['id_rutina']) ? intval($_GET['id_rutina']) : 0;
error_log("ID rutina recibido: " . $idRutina);

// Validar parámetro
if (!isset($_GET['id_rutina']) || !is_numeric($_GET['id_rutina'])) {
    echo json_encode(["error" => "Parámetro id_rutina inválido"]);
    exit;
}

$idRutina = intval($_GET['id_rutina']);

// Preparar consulta
$sql = "SELECT 
            re.id_rutina_ejercicio,
            e.nombre AS ejercicio,
            re.series,
            re.repeticiones,
            re.carga
        FROM rutina_ejercicios re
        INNER JOIN ejercicios e ON e.id_ejercicio = re.id_ejercicio
        WHERE re.id_rutina = ?";

$stmt = $mysqli->prepare($sql);
if (!$stmt) {
    echo json_encode(["error" => "Error en prepare: " . $mysqli->error]);
    exit;
}

$stmt->bind_param("i", $idRutina);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}

// Devolver JSON
echo json_encode($items, JSON_UNESCAPED_UNICODE);

$stmt->close();
$mysqli->close();
?>