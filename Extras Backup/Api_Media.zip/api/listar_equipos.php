<?php
header("Content-Type: application/json");
require_once "conexion.php";

$sql = "
SELECT 
    e.id_equipo AS id_equipo,
    e.nombre AS nombre,
    e.descripcion AS descripcion,
    e.estado AS estado
FROM equipos e
ORDER BY e.nombre;
";

$result = $mysqli->query($sql);

$datos = [];

if ($result) {
    while ($fila = $result->fetch_assoc()) {
        foreach ($fila as $k => $v) {
            if (is_null($v)) $fila[$k] = "";
            else $fila[$k] = (string)$v;
        }
        $datos[] = $fila;
    }
}

echo json_encode($datos, JSON_UNESCAPED_UNICODE);