<?php
include 'conexion.php';

if (!isset($_GET['ProductoID'])) {
    echo "0";
    exit;
}

$productoID = intval($_GET['ProductoID']);
$sql = "SELECT Stock FROM Productos WHERE ProductoID = $productoID";
$res = $mysqli->query($sql);

if ($res && $row = $res->fetch_assoc()) {
    echo $row['Stock']; // solo el número
} else {
    echo "0";
}

$mysqli->close();
?>