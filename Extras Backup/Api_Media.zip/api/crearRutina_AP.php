<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php"; // tu archivo de conexión a MySQL

$response = array("success" => false, "message" => "");

try {
    // Leer el JSON enviado desde Android
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    if (!$data) {
        throw new Exception("JSON inválido o vacío.");
    }

    $nombreRutina = $data["nombreRutina"] ?? null;
    $idAlumno     = $data["idAlumno"] ?? null;
    $ejercicios   = $data["ejercicios"] ?? [];

    if (!$nombreRutina || !$idAlumno || empty($ejercicios)) {
        throw new Exception("Faltan datos obligatorios.");
    }

    // Insertar rutina
    $stmt = $mysqli->prepare("INSERT INTO rutinas (nombre, id) VALUES (?, ?)");
    if (!$stmt) {
        throw new Exception("Error al preparar inserción de rutina: " . $mysqli->error);
    }
    $stmt->bind_param("si", $nombreRutina, $idAlumno);
    if (!$stmt->execute()) {
        throw new Exception("Error al insertar rutina: " . $stmt->error);
    }
    $idRutina = $stmt->insert_id;
    $stmt->close();

    // Insertar ejercicios de la rutina
    $stmtEj = $mysqli->prepare("INSERT INTO rutina_ejercicios (id_rutina, id_ejercicio, series, repeticiones, carga) VALUES (?, ?, ?, ?, ?)");
    if (!$stmtEj) {
        throw new Exception("Error al preparar inserción de ejercicios: " . $mysqli->error);
    }

    foreach ($ejercicios as $ej) {
        $idEjercicio  = $ej["idEjercicio"];
        $series       = $ej["series"];
        $repeticiones = $ej["repeticiones"];
        $carga        = $ej["carga"];

        $stmtEj->bind_param("iiiii", $idRutina, $idEjercicio, $series, $repeticiones, $carga);
        if (!$stmtEj->execute()) {
            throw new Exception("Error al insertar ejercicio: " . $stmtEj->error);
        }
    }
    $stmtEj->close();

    $response["success"] = true;
    $response["message"] = "Rutina creada correctamente.";
    $response["id_rutina"] = $idRutina;

} catch (Exception $e) {
    $response["success"] = false;
    $response["message"] = $e->getMessage();
} finally {
    $mysqli->close();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>