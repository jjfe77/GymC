<?php
header("Content-Type: application/json");
require_once "conexion.php";

$idAlumno = intval($_POST['id_alumno']);
$idRutina = intval($_POST['id_rutina']);
$idRutinaEjercicio = intval($_POST['id_rutina_ejercicio']);
$seriesReal = intval($_POST['series_real']);
$repReal = intval($_POST['repeticiones_real']);
$cargaReal = intval($_POST['carga_real']);

$response = ["success" => false]; // valor por defecto

// 1️⃣ Insert en ejercicios_realizados
$sql1 = "INSERT INTO ejercicios_realizados
        (id_alumno, id_rutina, id_rutina_ejercicio, series_real, repeticiones_real, carga_real, fecha)
        VALUES (?, ?, ?, ?, ?, ?, CURDATE())";

$stmt1 = $mysqli->prepare($sql1);
$stmt1->bind_param("iiiiii",
                  $idAlumno, $idRutina, $idRutinaEjercicio,
                  $seriesReal, $repReal, $cargaReal);

if ($stmt1->execute()) {
    $idRealOrigen = $stmt1->insert_id;
    $stmt1->close();

    // 2️⃣ Insert en ejercicios_progreso
    $sql2 = "INSERT INTO ejercicios_progreso
            (id_alumno, id_rutina, id_rutina_ejercicio, series_real, repeticiones_real, carga_real, fecha, id_real_origen)
            VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?)";

    $stmt2 = $mysqli->prepare($sql2);
    $stmt2->bind_param("iiiiiii",
                      $idAlumno, $idRutina, $idRutinaEjercicio,
                      $seriesReal, $repReal, $cargaReal, $idRealOrigen);

    if ($stmt2->execute()) {
        $idProgreso = $stmt2->insert_id;
        $stmt2->close();

        // 3️⃣ UPDATE nombre + plan
        $sqlUpdate = "UPDATE ejercicios_progreso ep
                      JOIN rutina_ejercicios re ON ep.id_rutina_ejercicio = re.id_rutina_ejercicio
                      JOIN ejercicios e ON re.id_ejercicio = e.id_ejercicio
                      SET ep.nombre_ejercicio = e.nombre,
                          ep.series_plan = re.series,
                          ep.repes_plan = re.repeticiones,
                          ep.carga_plan = re.carga
                      WHERE ep.id_real = ?";
        $stmtUpdate = $mysqli->prepare($sqlUpdate);
        $stmtUpdate->bind_param("i", $idProgreso);
        $stmtUpdate->execute();
        $stmtUpdate->close();

        $response["success"] = true;
    } else {
        $response["error"] = $stmt2->error;
    }
} else {
    $response["error"] = $stmt1->error;
}

echo json_encode($response);
$mysqli->close();
?>
