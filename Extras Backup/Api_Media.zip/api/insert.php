<?php
header('Content-Type: application/json');
include 'conexion.php';

$id_usuario = $_POST['id_usuario'] ?? '';
$fecha_inscripcion = $_POST['fecha_inscripcion'] ?? '';
$ultima_fecha_pago = $_POST['ultima_fecha_pago'] ?? '';
$fecha_vencimiento = $_POST['fecha_vencimiento'] ?? '';
$tipo_membresia = $_POST['tipo_membresia'] ?? '';

if ($id_usuario === '') {
    echo json_encode(["error" => "Falta id_usuario"]);
    exit;
}

// Cálculo del estado automáticamente
$hoy = date('Y-m-d');
$estado = ($fecha_vencimiento < $hoy) ? "Vencida" : "Activa";

$sql = "INSERT INTO cuotas 
(id_usuario, fecha_inscripcion, ultima_fecha_pago, fecha_vencimiento, tipo_membresia, estado)
VALUES 
('$id_usuario', '$fecha_inscripcion', '$ultima_fecha_pago', '$fecha_vencimiento', '$tipo_membresia', '$estado')";

if ($mysqli->query($sql)) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["error" => $mysqli->error]);
}
?>
