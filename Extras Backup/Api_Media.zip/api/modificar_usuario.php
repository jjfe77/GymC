<?php
include 'conexion.php'; // Conexión centralizada

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $dni = $_GET['dni'];
    $nombre = $_GET['nombre'];
    $apellido = $_GET['apellido'];
    $rol = $_GET['rol'];
    $edad = $_GET['edad'];
    $peso = $_GET['peso'];
    $altura = $_GET['altura'];
    $grupo = $_GET['grupo_sanguineo'];
    $direccion = $_GET['direccion'];
    $telefono = $_GET['telefono'];

    // Preparar la consulta para evitar inyecciones SQL
    $stmt = $mysqli->prepare(
        "UPDATE usuarios SET dni=?, nombre=?, apellido=?, rol=?, edad=?, peso=?, altura=?, grupo_sanguineo=?, direccion=?, telefono=? WHERE id=?"
    );
    $stmt->bind_param(
        "ssssiddsssi",
        $dni, $nombre, $apellido, $rol, $edad, $peso, $altura, $grupo, $direccion, $telefono, $id
    );

    if($stmt->execute()){
        echo json_encode(["success" => "Usuario modificado correctamente"]);
    } else {
        echo json_encode(["error" => $stmt->error]);
    }

    $stmt->close();
    $mysqli->close();
}
?>

