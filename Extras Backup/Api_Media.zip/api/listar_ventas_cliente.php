<?php
header('Content-Type: application/json');
include 'conexion.php';

$clienteID = $_GET['ClienteID'];

$sql = "SELECT VentaID, FechaVenta 
        FROM Ventas 
        WHERE ClienteID = ? 
        ORDER BY FechaVenta DESC";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $clienteID);
$stmt->execute();
$result = $stmt->get_result();

$ventas = array();
while ($row = $result->fetch_assoc()) {
    $ventas[] = array(
        "VentaID"    => strval($row["VentaID"]),
        "FechaVenta" => strval($row["FechaVenta"])
    );
}

echo json_encode($ventas);
$mysqli->close();
?>