<?php





header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php";

$idRutina = isset($_GET['id_rutina']) ? intval($_GET['id_rutina']) : 0;

if ($idRutina <= 0) {
    echo json_encode(["status" => "error", "msg" => "ID de rutina inválido"]);
    exit();
}

$sql = "SELECT 
            re.id_rutina_ejercicio,
            re.id_ejercicio,
            e.nombre,
            re.series,
            re.repeticiones,
            re.carga
        FROM rutina_ejercicios re
        INNER JOIN ejercicios e ON re.id_ejercicio = e.id_ejercicio
        WHERE re.id_rutina = ?";

$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $idRutina);

if (!$stmt->execute()) {
    echo json_encode(["status" => "error", "msg" => $stmt->error]);
    exit();
}

$result = $stmt->get_result();
$ejercicios = [];

while ($row = $result->fetch_assoc()) {
    $ejercicios[] = [
        "id_rutina_ejercicio" => (int)$row["id_rutina_ejercicio"],
        "id_ejercicio"        => (int)$row["id_ejercicio"],
        "nombre"              => $row["nombre"],
        "series"              => (int)$row["series"],
        "repeticiones"        => (int)$row["repeticiones"],
        "carga"               => (int)$row["carga"],
    ];
}

echo json_encode(["status" => "ok", "ejercicios" => $ejercicios], JSON_UNESCAPED_UNICODE);

$stmt->close();
$mysqli->close();










































/*
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php";

// Recibir id_rutina por GET o POST
$idRutina = isset($_GET['id_rutina']) ? intval($_GET['id_rutina']) : intval($_POST['id_rutina'] ?? 0);

if ($idRutina <= 0) {
    echo json_encode(["status" => "error", "msg" => "ID de rutina inválido"]);
    exit();
}

// Consulta con prepared statement sobre rutina_ejercicios
$sql = "SELECT re.id_ejercicio, e.nombre, re.series, re.repeticiones, re.carga
        FROM rutina_ejercicios re
        INNER JOIN ejercicios e ON re.id_ejercicio = e.id_ejercicio
        WHERE re.id_rutina = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $idRutina);

if (!$stmt->execute()) {
    echo json_encode(["status" => "error", "msg" => $stmt->error]);
    $stmt->close();
    $mysqli->close();
    exit();
}

$result = $stmt->get_result();
$ejercicios = [];

while ($row = $result->fetch_assoc()) {
    $ejercicios[] = [
        "id_ejercicio" => (int)$row["id_ejercicio"],
        "nombre"       => $row["nombre"],
        "series"       => (int)$row["series"],
        "repeticiones" => (int)$row["repeticiones"],
        "carga"        => (int)$row["carga"]
    ];
}

echo json_encode(["status" => "ok", "ejercicios" => $ejercicios], JSON_UNESCAPED_UNICODE);

$stmt->close();
$mysqli->close();*/
?>