<?php
header("Content-Type: application/json; charset=UTF-8");

// Mostrar errores solo en desarrollo
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "conexion.php";

// Verificar conexión
if (!$mysqli) {
    echo json_encode([]);
    exit;
}
$mysqli->set_charset("utf8mb4");

// Validar parámetro
if (!isset($_GET['id_alumno']) || !is_numeric($_GET['id_alumno'])) {
    echo json_encode([]);
    exit;
}
$idAlumno = intval($_GET['id_alumno']);

// Consulta a ejercicios_progreso
$sql = "SELECT 
            fecha,
            nombre_ejercicio AS ejercicio,
            COALESCE(series_plan,0) AS series_plan,
            COALESCE(series_real,0) AS series_real,
            COALESCE(repes_plan,0) AS repes_plan,
            COALESCE(repeticiones_real,0) AS repes_real,
            COALESCE(carga_plan,0) AS carga_plan,
            COALESCE(carga_real,0) AS carga_real
        FROM ejercicios_progreso
        WHERE id_alumno = ?
        ORDER BY fecha ASC";

$stmt = $mysqli->prepare($sql);
if (!$stmt) {
    echo json_encode([]); // devuelve array vacío si falla prepare
    exit;
}

$stmt->bind_param("i", $idAlumno);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
while ($row = $result->fetch_assoc()) {
    // Forzar tipos para Android
    $items[] = [
        'fecha' => $row['fecha'],
        'ejercicio' => $row['ejercicio'],
        'series_plan' => intval($row['series_plan']),
        'series_real' => intval($row['series_real']),
        'repes_plan' => intval($row['repes_plan']),
        'repes_real' => intval($row['repes_real']),
        'carga_plan' => floatval($row['carga_plan']),
        'carga_real' => floatval($row['carga_real'])
    ];
}

// Devuelve siempre un JSONArray válido
echo json_encode($items, JSON_UNESCAPED_UNICODE);

$stmt->close();
$mysqli->close();
?>
