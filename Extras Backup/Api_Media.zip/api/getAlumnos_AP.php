<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php"; // tu archivo de conexión a MySQL

$sql = "SELECT id, CONCAT(apellido, ' ', nombre) AS nombre_completo
        FROM usuarios
        WHERE rol = 'Alumno'
        ORDER BY apellido";

$result = $mysqli->query($sql);

$alumnos = [];
while ($row = $result->fetch_assoc()) {
    $alumnos[] = [
        "id" => (int)$row["id"],
        "nombre" => $row["nombre_completo"]
    ];
}

echo json_encode($alumnos, JSON_UNESCAPED_UNICODE);

$mysqli->close();
?>