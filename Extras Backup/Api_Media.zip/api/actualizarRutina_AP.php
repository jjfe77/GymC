<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php"; // usa $mysqli

$response = ["success" => false, "message" => "", "data" => []];

try {

    // Leer JSON enviado por Android
    $input = json_decode(file_get_contents("php://input"), true);

    if (!$input) {
        throw new Exception("No se recibió JSON válido.");
    }

    $idRutina = $input["id_rutina"] ?? null;
    $ejercicios = $input["ejercicios"] ?? null;

    if (!$idRutina) {
        throw new Exception("Falta el parámetro id_rutina.");
    }

    if (!is_array($ejercicios)) {
        throw new Exception("Falta el arreglo de ejercicios.");
    }

    // 1) BORRAR ejercicios actuales de la rutina
    $sqlDelete = "DELETE FROM rutina_ejercicios WHERE id_rutina = ?";
    $stmtDel = $mysqli->prepare($sqlDelete);
    if (!$stmtDel) {
        throw new Exception("Error al preparar DELETE: " . $mysqli->error);
    }
    $stmtDel->bind_param("i", $idRutina);
    $stmtDel->execute();
    $stmtDel->close();

    // 2) INSERTAR ejercicios nuevos
    $sqlInsert = "INSERT INTO rutina_ejercicios (id_rutina, id_ejercicio, series, repeticiones, carga)
                  VALUES (?, ?, ?, ?, ?)";
    $stmtIns = $mysqli->prepare($sqlInsert);
    if (!$stmtIns) {
        throw new Exception("Error al preparar INSERT: " . $mysqli->error);
    }

    foreach ($ejercicios as $ej) {

        $idEjercicio = $ej["id_ejercicio"];
        $series = $ej["series"];
        $reps = $ej["repeticiones"];
        $carga = $ej["carga"];

        $stmtIns->bind_param("iiiid", $idRutina, $idEjercicio, $series, $reps, $carga);
        $stmtIns->execute();
    }

    $stmtIns->close();

    // Respuesta final
    $response["success"] = true;
    $response["message"] = "Rutina actualizada correctamente.";
    $response["data"] = ["id_rutina" => $idRutina];

} catch (Exception $e) {

    $response["success"] = false;
    $response["message"] = $e->getMessage();

} finally {
    $mysqli->close();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>