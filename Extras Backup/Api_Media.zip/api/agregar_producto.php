<?php
header('Content-Type: application/json');
include 'conexion.php'; // conexión centralizada

$nombre     = $_POST['Nombre'] ?? '';
$descripcion= $_POST['Descripcion'] ?? '';
$precio     = $_POST['Precio'] ?? '';
$stock      = $_POST['Stock'] ?? '';


if ($nombre === '' || $descripcion === '' || $precio === '' || $stock === '' ) {
    echo json_encode(["error" => "Faltan datos obligatorios"]);
    exit;
}

$stmt = $mysqli->prepare(
    "INSERT INTO Productos (Nombre, Descripcion, Precio, Stock) 
     VALUES (?, ?, ?, ?)"
);

if ($stmt === false) {
    echo json_encode(["error" => $mysqli->error]);
    exit;
}

// Precio puede ser decimal, Stock y Categoria enteros
$stmt->bind_param("ssdi", $nombre, $descripcion, $precio, $stock);

if ($stmt->execute()) {
    $nuevoID = $mysqli->insert_id;
    echo json_encode([
        "success" => "Producto agregado correctamente",
        "ProductoID" => $nuevoID
    ]);
} else {
    echo json_encode(["error" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>