<?php
header('Content-Type: application/json; charset=UTF-8');
require_once "conexion.php";

if (!isset($_GET['dni']) || !is_numeric($_GET['dni'])) {
    echo json_encode(["error" => "dni inválido"]);
    exit;
}

$dni = intval($_GET['dni']);

$sql = "SELECT id FROM usuarios WHERE dni = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("i", $dni);
$stmt->execute();

$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    echo json_encode(["id" => $row["id"]]);
} else {
    echo json_encode(["id" => 0]);
}

$stmt->close();
$mysqli->close();
?>
