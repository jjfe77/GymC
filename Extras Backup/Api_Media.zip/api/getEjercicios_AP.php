<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php"; // tu archivo de conexión a MySQL

$sql = "SELECT id_ejercicio, nombre 
        FROM ejercicios 
        ORDER BY nombre";

$result = $mysqli->query($sql);

$ejercicios = [];
while ($row = $result->fetch_assoc()) {
    $ejercicios[] = [
        "id_ejercicio" => (int)$row["id_ejercicio"],
        "nombre" => $row["nombre"]
    ];
}

echo json_encode($ejercicios, JSON_UNESCAPED_UNICODE);

$mysqli->close();
?>