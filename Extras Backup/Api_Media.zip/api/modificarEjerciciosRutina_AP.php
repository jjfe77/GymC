<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php";

$response = ["success" => false, "message" => ""];

try {
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    if (!$data) throw new Exception("JSON inválido.");

    $idRutina   = $data["id_rutina"] ?? null;
    $ejercicios = $data["ejercicios"] ?? [];

    if (!$idRutina || empty($ejercicios)) {
        throw new Exception("Faltan datos obligatorios.");
    }

    // Iniciar transacción
    $mysqli->begin_transaction();

    // Borrar ejercicios actuales de la rutina
    $stmtDel = $mysqli->prepare("DELETE FROM rutina_ejercicios WHERE id_rutina = ?");
    $stmtDel->bind_param("i", $idRutina);
    if (!$stmtDel->execute()) throw new Exception("Error al borrar ejercicios: " . $stmtDel->error);
    $stmtDel->close();

    // Insertar nuevos ejercicios
    $stmtIns = $mysqli->prepare("INSERT INTO rutina_ejercicios (id_rutina, id_ejercicio, series, repeticiones, carga) VALUES (?, ?, ?, ?, ?)");
    foreach ($ejercicios as $ej) {
        $idEjercicio  = $ej["idEjercicio"];
        $series       = $ej["series"];
        $repeticiones = $ej["repeticiones"];
        $carga        = $ej["carga"];

        $stmtIns->bind_param("iiiii", $idRutina, $idEjercicio, $series, $repeticiones, $carga);
        if (!$stmtIns->execute()) throw new Exception("Error al insertar ejercicio: " . $stmtIns->error);
    }
    $stmtIns->close();

    $mysqli->commit();

    $response["success"] = true;
    $response["message"] = "Ejercicios de la rutina modificados correctamente.";

} catch (Exception $e) {
    $mysqli->rollback();
    $response["success"] = false;
    $response["message"] = $e->getMessage();
} finally {
    $mysqli->close();
}

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>