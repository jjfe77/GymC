<?php
header('Content-Type: application/json');
include 'conexion.php'; // Conexión centralizada

// Obtenemos los datos (puede ser GET o POST, según tu implementación)
$nombre   = $_POST['nombre']   ?? '';
$apellido = $_POST['apellido'] ?? '';
$contacto = $_POST['contacto'] ?? '';

if ($nombre === '' || $apellido === '') {
    echo json_encode(["error" => "Faltan datos obligatorios"]);
    exit;
}

// Preparar consulta segura
$stmt = $mysqli->prepare(
    "INSERT INTO Clientes (Nombre, Apellido, Contacto) VALUES (?, ?, ?)"
);
$stmt->bind_param("sss", $nombre, $apellido, $contacto);

if ($stmt->execute()) {
    $nuevoID = $mysqli->insert_id; // ID autogenerado
    echo json_encode([
        "success" => "Cliente agregado correctamente",
        "ClienteID" => $nuevoID
    ]);
} else {
    echo json_encode(["error" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>