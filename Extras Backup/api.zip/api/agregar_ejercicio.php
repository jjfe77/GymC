<?php
header("Content-Type: application/json");
require_once "conexion.php"; // tu archivo de conexión

// Recibir parámetros
$nombre      = $_POST['nombre'] ?? '';
$descripcion = $_POST['descripcion'] ?? '';
$id_grupo    = $_POST['id_grupo'] ?? 0;
$id_equipo   = $_POST['id_equipo'] ?? 0;

// Validar
if ($nombre == '' || $id_grupo == 0 || $id_equipo == 0) {
    echo json_encode(["status" => "error", "message" => "Datos incompletos"]);
    exit;
}

// Insertar
$stmt = $mysqli->prepare("INSERT INTO Ejercicios (nombre, descripcion, id_grupo, id_equipo) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssii", $nombre, $descripcion, $id_grupo, $id_equipo);

if ($stmt->execute()) {
    echo json_encode(["status" => "ok", "message" => "Ejercicio agregado"]);
} else {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>