<?php
// Configuración de conexión
$host = "localhost";
$usuario = "root";
$contrasena = "root";
$baseDatos = "GymBD";

// Crear conexión
$mysqli = new mysqli($host, $usuario, $contrasena, $baseDatos);

// Verificar conexión
if ($mysqli->connect_errno) {
    header('Content-Type: application/json');
    echo json_encode(["error" => "Error de conexión a la base de datos: " . $mysqli->connect_error]);
    exit;
}

// Establecer charset a UTF-8
$mysqli->set_charset("utf8");
?>
