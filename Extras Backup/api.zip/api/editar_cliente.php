<?php
header('Content-Type: application/json');
include 'conexion.php'; // tu conexión centralizada

$clienteID = $_POST['ClienteID'] ?? '';
$nombre    = $_POST['Nombre'] ?? '';
$apellido  = $_POST['Apellido'] ?? '';
$contacto  = $_POST['Contacto'] ?? '';

if ($clienteID === '' || $nombre === '' || $apellido === '') {
    echo json_encode(["error" => "Faltan datos obligatorios"]);
    exit;
}

$stmt = $mysqli->prepare(
    "UPDATE Clientes SET Nombre = ?, Apellido = ?, Contacto = ? WHERE ClienteID = ?"
);

if ($stmt === false) {
    echo json_encode(["error" => $mysqli->error]);
    exit;
}

$stmt->bind_param("sssi", $nombre, $apellido, $contacto, $clienteID);

if ($stmt->execute()) {
    echo json_encode(["success" => "Cliente actualizado correctamente"]);
} else {
    echo json_encode(["error" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>