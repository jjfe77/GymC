<?php
header("Content-Type: application/json; charset=utf-8");
require_once "conexion.php";

// Recibir parámetros
$id_rutina  = intval($_POST['id_rutina'] ?? 0);
$nombre     = $_POST['nombre'] ?? '';
$id_alumno  = intval($_POST['id_alumno'] ?? 0);
$ejercicios = isset($_POST['ejercicios']) ? json_decode($_POST['ejercicios'], true) : [];
$eliminar   = isset($_POST['eliminar']) ? json_decode($_POST['eliminar'], true) : []; // opcional

// Validación básica
if ($id_rutina == 0 || $nombre === '' || $id_alumno == 0) {
    echo json_encode(["status" => "error", "message" => "Datos incompletos"]);
    exit;
}

// Actualizar cabecera de rutina
$sql = "UPDATE rutinas SET nombre = ?, id = ? WHERE id_rutina = ?";
$stmt = $mysqli->prepare($sql);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Error en prepare: " . $mysqli->error]);
    exit;
}
$stmt->bind_param("sii", $nombre, $id_alumno, $id_rutina);
$stmt->execute();
$stmt->close();

// Borrar ejercicios marcados para eliminar
if (!empty($eliminar)) {
    foreach ($eliminar as $idRutinaEj) {
        $idRutinaEj = intval($idRutinaEj);
        if ($idRutinaEj > 0) {
            $sql = "DELETE FROM rutina_ejercicios WHERE id_rutina_ejercicio = ?";
            $stmt = $mysqli->prepare($sql);
            $stmt->bind_param("i", $idRutinaEj);
            $stmt->execute();
            $stmt->close();
        }
    }
}

// Insertar o actualizar ejercicios
foreach ($ejercicios as $ej) {
    $id_rutina_ejercicio = intval($ej['id_rutina_ejercicio'] ?? 0);
    $id_ejercicio = intval($ej['id_ejercicio'] ?? 0);
    $series       = intval($ej['series'] ?? 0);
    $repeticiones = intval($ej['repeticiones'] ?? 0);
    $carga        = intval($ej['carga'] ?? 0);

    if ($id_ejercicio == 0) continue;

    if ($id_rutina_ejercicio > 0) {
        // UPDATE existente
        $sql = "UPDATE rutina_ejercicios 
                SET id_ejercicio = ?, series = ?, repeticiones = ?, carga = ?
                WHERE id_rutina_ejercicio = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("iiiii", $id_ejercicio, $series, $repeticiones, $carga, $id_rutina_ejercicio);
    } else {
        // INSERT nuevo
        $sql = "INSERT INTO rutina_ejercicios (id_rutina, id_ejercicio, series, repeticiones, carga)
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("iiiii", $id_rutina, $id_ejercicio, $series, $repeticiones, $carga);
    }

    $stmt->execute();
    $stmt->close();
}

// Respuesta final
echo json_encode(["status" => "success", "message" => "Rutina actualizada correctamente"]);
$mysqli->close();
?>