<?php
header('Content-Type: application/json');
include 'conexion.php';

$id_usuario        = $_POST['id_usuario'] ?? '';
$ultima_fecha_pago = $_POST['ultima_fecha_pago'] ?? '';
$fecha_vencimiento = $_POST['fecha_vencimiento'] ?? '';
$tipo_membresia    = $_POST['tipo_membresia'] ?? '';

if ($id_usuario === '') {
    echo json_encode(["error" => "Falta id_usuario"]);
    exit;
}

$hoy = date('Y-m-d');

// Estado de la cuota
$estado = ($fecha_vencimiento < $hoy) ? "Vencida" : "Activa";

// Actualizar cuota
$stmt = $mysqli->prepare("UPDATE cuotas 
    SET ultima_fecha_pago = ?, 
        fecha_vencimiento = ?, 
        tipo_membresia = ?, 
        estado = ?
    WHERE id_usuario = ?");
$stmt->bind_param("sssss", $ultima_fecha_pago, $fecha_vencimiento, $tipo_membresia, $estado, $id_usuario);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    // Si está vencida, verificamos si pasaron más de 90 días
    if ($estado === "Vencida") {
        $dias_diferencia = (strtotime($hoy) - strtotime($fecha_vencimiento)) / (60 * 60 * 24);
        if ($dias_diferencia > 90) {
            // Actualizar usuario a Inactiva
            $stmt2 = $mysqli->prepare("UPDATE usuarios SET estado_cliente = 'Inactiva' WHERE id = ?");
            $stmt2->bind_param("s", $id_usuario);
            $stmt2->execute();
            $stmt2->close();
        }
    }

    echo json_encode(["success" => true]);
} else {
    echo json_encode(["error" => "No se pudo guardar la cuota"]);
}

$stmt->close();
$mysqli->close();
?>