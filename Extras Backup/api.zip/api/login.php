<?php
header('Content-Type: application/json');
include 'conexion.php'; // Incluimos la conexión centralizada

// Obtener DNI desde GET
$dni = $_GET['dni'] ?? '';

if ($dni === '') {
    echo json_encode(["rol" => ""]);
    exit;
}

// Preparar la consulta
$stmt = $mysqli->prepare("SELECT rol FROM usuarios WHERE dni = ?");
$stmt->bind_param("s", $dni);
$stmt->execute();
$result = $stmt->get_result();

// Devolver el rol en JSON
if ($row = $result->fetch_assoc()) {
    echo json_encode(["rol" => $row['rol']]);
} else {
    echo json_encode(["rol" => ""]);
}

$stmt->close();
$mysqli->close();
?>
