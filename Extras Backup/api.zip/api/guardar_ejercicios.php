<?php
header("Content-Type: application/json");
require_once "conexion.php";

$idAlumno = intval($_POST['id_alumno']);
$idRutina = intval($_POST['id_rutina']);
$idRutinaEjercicio = intval($_POST['id_rutina_ejercicio']);
$seriesReal = intval($_POST['series_real']);
$repesReal = intval($_POST['repeticiones_real']);
$cargaReal = intval($_POST['carga_real']);
$fecha = $_POST['fecha']; // viene del DateTimePicker

$sql = "INSERT INTO ejercicios_realizados 
        (id_alumno, id_rutina, id_rutina_ejercicio, series_real, repeticiones_real, carga_real, fecha)
        VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("iiiiiss", $idAlumno, $idRutina, $idRutinaEjercicio, $seriesReal, $repesReal, $cargaReal, $fecha);

if ($stmt->execute()) {
    echo json_encode(["status" => "ok"]);
} else {
    echo json_encode(["status" => "error", "msg" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>