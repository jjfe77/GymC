<?php
header('Content-Type: application/json');
include 'conexion.php';

$sql = "SELECT v.VentaID, c.Nombre AS ClienteNombre, v.FechaVenta, v.Total
        FROM Ventas v
        INNER JOIN Clientes c ON v.ClienteID = c.ClienteID
        ORDER BY v.FechaVenta DESC";

$result = $mysqli->query($sql);

$ventas = array();
while ($row = $result->fetch_assoc()) {
    $ventas[] = array(
        "VentaID"       => strval($row["VentaID"]),
        "ClienteNombre" => strval($row["ClienteNombre"]),
        "FechaVenta"    => strval($row["FechaVenta"]),
        "Total"         => strval($row["Total"])
    );
}

echo json_encode($ventas);
$mysqli->close();
?>