<?php
header('Content-Type: application/json');
include 'conexion.php'; // incluimos la conexión

$result = $mysqli->query("SELECT * FROM usuarios");

$usuarios = [];
while ($row = $result->fetch_assoc()) {
    $usuarios[] = $row;
}

echo json_encode($usuarios, JSON_UNESCAPED_UNICODE);
?>

