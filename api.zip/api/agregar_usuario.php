<?php
header('Content-Type: application/json');
include 'conexion.php'; // Conexión centralizada

// Obtenemos los datos de GET (o POST si lo cambias)
$dni = $_GET['dni'] ?? '';
$nombre = $_GET['nombre'] ?? '';
$apellido = $_GET['apellido'] ?? '';
$rol = $_GET['rol'] ?? '';
$edad = $_GET['edad'] ?? '';
$peso = $_GET['peso'] ?? '';
$altura = $_GET['altura'] ?? '';
$grupo_sanguineo = $_GET['grupo_sanguineo'] ?? '';
$direccion = $_GET['direccion'] ?? '';
$telefono = $_GET['telefono'] ?? '';

if ($dni === '' || $nombre === '' || $apellido === '' || $rol === '') {
    echo json_encode(["error" => "Faltan datos obligatorios"]);
    exit;
}

// Preparar consulta para evitar inyecciones SQL
$stmt = $mysqli->prepare(
    "INSERT INTO usuarios (dni, nombre, apellido, rol, edad, peso, altura, grupo_sanguineo, direccion, telefono)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param("ssssiddsss", $dni, $nombre, $apellido, $rol, $edad, $peso, $altura, $grupo_sanguineo, $direccion, $telefono);

if ($stmt->execute()) {
    echo json_encode(["success" => "Usuario agregado correctamente"]);
} else {
    echo json_encode(["error" => $stmt->error]);
}

$stmt->close();
$mysqli->close();
?>
